import React, { useState } from 'react';
import { Send, Music } from 'lucide-react';

interface Message {
  text: string;
  isUser: boolean;
}

interface SoundtrackCategory {
  [key: string]: string[];
}

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');

  const soundtracksByCategory: SoundtrackCategory = {
    hollywood: [
      "Hans Zimmer - Time (Inception)",
      "John Williams - Imperial March (Star Wars)",
      "Howard Shore - The Shire (Lord of the Rings)",
      "Ludwig Göransson - The Mandalorian Theme",
      "Ramin Djawadi - Light of the Seven (Game of Thrones)",
      "Michael Giacchino - Married Life (Up)",
      "Alan Silvestri - Portals (Avengers: Endgame)",
      "James Horner - My Heart Will Go On (Titanic)",
      "Danny Elfman - This Is Halloween (The Nightmare Before Christmas)",
      "John Williams - Hedwig's Theme (Harry Potter)",
      "Hans Zimmer - Circle of Life (The Lion King)",
      "Randy Newman - You've Got a Friend in Me (Toy Story)"
    ],
    bollywood: [
      "A.R. Rahman - Jai Ho (Slumdog Millionaire)",
      "Pritam - Kesariya (Brahmastra)",
      "A.R. Rahman - Chaiyya Chaiyya (Dil Se)",
      "Vishal-Shekhar - Jhoome Jo Pathaan (Pathaan)",
      "Amit Trivedi - Iktara (Wake Up Sid)",
      "Shankar-Ehsaan-Loy - Kal Ho Naa Ho (Kal Ho Naa Ho)",
      "R.D. Burman - Chura Liya Hai Tumne (Yaadon Ki Baaraat)",
      "A.R. Rahman - Dil Se Re (Dil Se)",
      "Pritam - Tum Hi Ho (Aashiqui 2)",
      "M.M. Keeravani - Naatu Naatu (RRR)"
    ],
    international: [
      "Joe Hisaishi - One Summer's Day (Spirited Away)",
      "Yann Tiersen - Comptine d'un autre été (Amélie)",
      "Ryuichi Sakamoto - Merry Christmas Mr. Lawrence",
      "Gustavo Santaolalla - The Last of Us Theme",
      "Ramin Djawadi - Westworld Theme",
      "Klaus Badelt - He's a Pirate (Pirates of the Caribbean)",
      "Vangelis - Chariots of Fire Theme",
      "Junkie XL - Brothers in Arms (Mad Max: Fury Road)",
      "Ludwig Göransson - Wakanda (Black Panther)",
      "Tan Dun - Hero Theme (Hero)"
    ],
    epic: [
      "Hans Zimmer - Time (Inception)",
      "Howard Shore - The Shire (Lord of the Rings)",
      "Ramin Djawadi - Light of the Seven (Game of Thrones)",
      "Alan Silvestri - Portals (Avengers: Endgame)",
      "M.M. Keeravani - Naatu Naatu (RRR)",
      "Ludwig Göransson - Wakanda (Black Panther)"
    ],
    romantic: [
      "James Horner - My Heart Will Go On (Titanic)",
      "Pritam - Kesariya (Brahmastra)",
      "Shankar-Ehsaan-Loy - Kal Ho Naa Ho (Kal Ho Naa Ho)",
      "Pritam - Tum Hi Ho (Aashiqui 2)",
      "Yann Tiersen - Comptine d'un autre été (Amélie)"
    ]
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const newUserMessage = { text: input, isUser: true };
    let botResponse: Message;

    const userInput = input.toLowerCase();

    if (userInput.includes('sound')) {
      let response: string;

      // Check for specific commands
      if (userInput.includes('hollywood')) {
        const track = soundtracksByCategory.hollywood[Math.floor(Math.random() * soundtracksByCategory.hollywood.length)];
        response = `Here's a Hollywood soundtrack: ${track}`;
      } else if (userInput.includes('bollywood')) {
        const track = soundtracksByCategory.bollywood[Math.floor(Math.random() * soundtracksByCategory.bollywood.length)];
        response = `Here's a Bollywood soundtrack: ${track}`;
      } else if (userInput.includes('international')) {
        const track = soundtracksByCategory.international[Math.floor(Math.random() * soundtracksByCategory.international.length)];
        response = `Here's an international soundtrack: ${track}`;
      } else if (userInput.includes('epic')) {
        const track = soundtracksByCategory.epic[Math.floor(Math.random() * soundtracksByCategory.epic.length)];
        response = `Here's an epic soundtrack: ${track}`;
      } else if (userInput.includes('romantic')) {
        const track = soundtracksByCategory.romantic[Math.floor(Math.random() * soundtracksByCategory.romantic.length)];
        response = `Here's a romantic soundtrack: ${track}`;
      } else if (userInput.includes('help')) {
        response = `Available commands:
• "sound hollywood" - Get a Hollywood soundtrack
• "sound bollywood" - Get a Bollywood soundtrack
• "sound international" - Get an international soundtrack
• "sound epic" - Get an epic soundtrack
• "sound romantic" - Get a romantic soundtrack
• "sound" - Get a random soundtrack from any category`;
      } else {
        // Random soundtrack from any category
        const categories = Object.keys(soundtracksByCategory);
        const randomCategory = categories[Math.floor(Math.random() * categories.length)];
        const track = soundtracksByCategory[randomCategory][Math.floor(Math.random() * soundtracksByCategory[randomCategory].length)];
        response = `Here's a random soundtrack: ${track}`;
      }

      botResponse = {
        text: response,
        isUser: false
      };
    } else {
      botResponse = {
        text: 'Try these commands:\n• "sound help" - See all available commands\n• "sound" - Get a random soundtrack',
        isUser: false
      };
    }

    setMessages([...messages, newUserMessage, botResponse]);
    setInput('');
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl overflow-hidden">
        <div className="bg-indigo-600 p-4 flex items-center gap-2">
          <Music className="text-white" size={24} />
          <h1 className="text-xl font-bold text-white">AI Soundtrack Recommender</h1>
        </div>
        
        <div className="h-[400px] overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-gray-500">
              Type "sound help" to see all available commands!
            </div>
          )}
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.isUser
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-200 text-gray-800'
                }`}
              >
                {message.text.split('\n').map((line, i) => (
                  <React.Fragment key={i}>
                    {line}
                    {i < message.text.split('\n').length - 1 && <br />}
                  </React.Fragment>
                ))}
              </div>
            </div>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="p-4 border-t">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder='Try typing "sound help" to see all commands...'
              className="flex-1 rounded-lg border border-gray-300 p-2 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              className="bg-indigo-600 text-white p-2 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Send size={20} />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default App;